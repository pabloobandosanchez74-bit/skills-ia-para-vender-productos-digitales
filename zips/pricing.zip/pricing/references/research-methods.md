# Pricing Research Methods

## Contents
- Van Westendorp Price Sensitivity Meter (The Four Questions, How to Analyze, Survey Tips, Sample Output)
- MaxDiff Analysis (How It Works, Example Survey Question, Analyzing Results, Using MaxDiff for Packaging)
- Willingness to Pay Surveys
- Usage-Value Correlation Analysis

## Van Westendorp Price Sensitivity Meter

The Van Westendorp survey identifies the acceptable price range for your product.

### The Four Questions

Ask each respondent:
1. "At what price would you consider [product] to be so expensive that you would not consider buying it?" (Too expensive)
2. "At what price would you consider [product] to be priced so low that you would question its quality?" (Too cheap)
3. "At what price would you consider [product] to be starting to get expensive, but you still might consider it?" (Expensive/high side)
4. "At what price would you consider [product] to be a bargain—a great buy for the money?" (Cheap/good value)

### How to Analyze

1. Validate responses in one currency, billing period, and product description. Flag missing, nonnumeric, or inconsistent threshold ordering (`too cheap ≤ cheap ≤ expensive ≤ too expensive`); document any exclusions instead of silently changing answers.
2. Plot candidate price on the x-axis and the share of respondents on the y-axis. The two cheap curves decrease as price rises; the two expensive curves increase. At each candidate price `p`, use:

   | Curve | Share to plot | Direction |
   |-------|---------------|-----------|
   | Too cheap | Respondents whose too-cheap threshold is at or above `p` | Decreasing |
   | Cheap / good value | Respondents whose cheap threshold is at or above `p` | Decreasing |
   | Expensive | Respondents whose expensive threshold is at or below `p` | Increasing |
   | Too expensive | Respondents whose too-expensive threshold is at or below `p` | Increasing |

   Use a consistent endpoint convention for ties and record it. Do not apply an increasing cumulative distribution to all four questions: it reverses the meaning of the cheap curves. [Sawtooth's example](https://sawtoothsoftware.com/resources/blog/posts/van-westendorp-pricing-sensitivity-meter) illustrates the too-cheap share falling as price increases.
3. Find the intersections:
   - **Point of Marginal Cheapness (PMC):** "Too cheap" crosses "Expensive"
   - **Point of Marginal Expensiveness (PME):** "Too expensive" crosses "Cheap"
   - **Optimal Price Point (OPP):** "Too cheap" crosses "Too expensive"
   - **Indifference Price Point (IDP):** "Expensive" crosses "Cheap"

**The acceptable price range:** PMC to PME
**Candidate prices to test:** OPP and IDP can inform a shortlist; they do not establish an economically optimal zone.

The four questions measure price perceptions, not purchase probabilities. Before forecasting demand, use additional purchase-intent research (such as the Newton-Miller-Smith extension, with its assumptions stated), a choice study or actual price tests. Compare revenue, margin and retention; a higher acceptable price does not guarantee unchanged demand. See [Sawtooth's explanation of the method and its limits](https://sawtoothsoftware.com/resources/blog/posts/van-westendorp-pricing-sensitivity-meter).

### Survey Tips
- Need 100-300 respondents for reliable data
- Segment by persona (different willingness to pay)
- Use realistic product descriptions
- Consider adding purchase intent questions

### Sample Output

```
Price Sensitivity Analysis Results:
─────────────────────────────────
Point of Marginal Cheapness:  $29/mo
Optimal Price Point:          $49/mo
Indifference Price Point:     $59/mo
Point of Marginal Expensiveness: $79/mo

Candidate test prices: $49 and $59/mo
Current price: $39/mo
Price changes: +25.6% and +51.3%
Demand, conversion and churn impact: not measured by these four questions
Next step: validate purchase behavior and unit economics before rollout
```

---

## MaxDiff Analysis (Best-Worst Scaling)

MaxDiff identifies which features customers value most, informing packaging decisions.

### How It Works

1. List 8-15 features you could include
2. Show respondents sets of 4-5 features at a time
3. Ask: "Which is MOST important? Which is LEAST important?"
4. Repeat across multiple sets until all features compared
5. Statistical analysis produces importance scores

### Example Survey Question

```
Which feature is MOST important to you?
Which feature is LEAST important to you?

□ Unlimited projects
□ Custom branding
□ Priority support
□ API access
□ Advanced analytics
```

### Analyzing Results

Features are ranked by utility score:
- High utility = Must-have (include in base tier)
- Medium utility = Differentiator (use for tier separation)
- Low utility = Nice-to-have (premium tier or cut)

### Using MaxDiff for Packaging

| Utility Score | Packaging Decision |
|---------------|-------------------|
| Top 20% | Include in all tiers (table stakes) |
| 20-50% | Use to differentiate tiers |
| 50-80% | Higher tiers only |
| Bottom 20% | Consider cutting or premium add-on |

---

## Willingness to Pay Surveys

**Direct method (simple but biased):**
"How much would you pay for [product]?"

**Better: Gabor-Granger method:**
"Would you buy [product] at [$X]?" (Yes/No)
Vary price across respondents to build demand curve.

**Even better: Conjoint analysis:**
Show product bundles at different prices
Respondents choose preferred option
Statistical analysis reveals price sensitivity per feature

---

## Usage-Value Correlation Analysis

### 1. Instrument usage data
Track how customers use your product:
- Feature usage frequency
- Volume metrics (users, records, API calls)
- Outcome metrics (revenue generated, time saved)

### 2. Correlate with customer success
- Which usage patterns predict retention?
- Which usage patterns predict expansion?
- Which customers pay the most, and why?

### 3. Identify value thresholds
- At what usage level do customers "get it"?
- At what usage level do they expand?
- At what usage level should price increase?

### Example Analysis

```
Usage-Value Correlation Analysis:
─────────────────────────────────
Segment: High-LTV customers (>$10k ARR)
Average monthly active users: 15
Average projects: 8
Average integrations: 4

Segment: Churned customers
Average monthly active users: 3
Average projects: 2
Average integrations: 0

Insight: Value correlates with team adoption (users)
        and depth of use (integrations)

Recommendation: Price per user, gate integrations to higher tiers
```
